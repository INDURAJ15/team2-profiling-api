# Team 2 – End-to-End Data Profiling Integration

## Integration flow
1. Client prepares a request using `profiling_request.schema.json`.
2. Client sends `POST /api/v1/profiling/`.
3. FastAPI validates the request and invokes the profiling adapter.
4. The adapter loads the CSV/XLSX dataset.
5. The adapter calculates row/column counts, duplicates, missing values, inferred types,
   optional numerical summaries, histograms, top values, correlations, and target distribution.
6. API returns a JSON response.
7. Client validates the response and handles `success`, `warning`, or `failed`.

## Local verification recorded
- Adapter import: `Adapter import successful`.
- Direct HR Employee XLSX adapter run: `warning`, with an empty errors array.
- TestClient call to `POST /api/v1/profiling/`: HTTP 200.
- Tested HR Employee dataset: 290 rows, 16 columns, 0 duplicate rows.
- Correlation serialization issue involving NaN was addressed; the endpoint test then returned HTTP 200.

## Pending before final sign-off
- Team 1 contract version is `1.0-draft`; confirm acceptance before freezing it.
- Validate the actual API response against Team 1's exact response schema.
- Confirm request-model support for all metadata fields, especially `missing_value_markers`.
- Confirm how `dataset_reference.name` is propagated; current test output used `hr_employee`.
- Test success, warning, invalid request, and source-not-found scenarios.
- Ensure file paths are accessible on the API host and are not returned in responses.

The sample response is abbreviated for documentation and is not the full 290-row/16-column output.
