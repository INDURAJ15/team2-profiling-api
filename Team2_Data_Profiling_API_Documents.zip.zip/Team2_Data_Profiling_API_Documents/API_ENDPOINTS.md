# Team 2 Data Profiling API Endpoints

## Base URL
`http://127.0.0.1:8000`

## Profiling endpoint
- Method: `POST`
- Path: `/api/v1/profiling/`
- Purpose: Load a CSV/XLSX dataset and return dataset-level and column-level profiling.
- Swagger UI: `http://127.0.0.1:8000/docs`

Send a JSON body matching `profiling_request.schema.json`. The `dataset_reference.location`
must be accessible from the machine running the API.

## Example cURL
```bash
curl -X POST "http://127.0.0.1:8000/api/v1/profiling/" \
  -H "Content-Type: application/json" \
  -d @sample_profiling_request.json
```

## Health endpoints
- `GET /` — service status.
- `GET /health` — health check.

The HTTP response may carry a business status of `success`, `warning`, or `failed`.
